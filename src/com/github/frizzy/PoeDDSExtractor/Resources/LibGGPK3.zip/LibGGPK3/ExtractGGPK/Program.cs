﻿using System.Runtime.InteropServices;
using LibBundle3.Nodes;
using LibBundledGGPK3;
using LibGGPK3;
using Index = LibBundle3.Index;

namespace ExtractGGPK;

public class Program
{
    
    public static void Main(string[ ] args )
    {
        
        if ( args.Length == 0 )
        {
            args = new string[3];
            Console.Write("Path to Content.ggpk or _.index.bin: ");
            args[0] = Console.ReadLine()!;
            Console.Write("Path to directory/file to extract: ");
            args[1] = Console.ReadLine()!;
            Console.Write("Path to save the extracted directory/file: ");
            args[2] = Console.ReadLine()!;
            
        } else if ( args.Length != 3)
        {
            Console.WriteLine("Usage: ExtractGGPK3 <PathToGGPK> <PathToExtract> <PathToSave>");
            Console.WriteLine();
            Console.WriteLine("Enter to exit . . .");
            Console.ReadLine();
            return;
        }
        
        var contentPath = args[0].Trim('"');
        var nodePath = args[1].TrimEnd('/').Trim('"');
        var outPath = args[2].Trim('"');

        if (!File.Exists(contentPath))
        {
            Console.WriteLine("FileNotFound: " + contentPath);
            Console.WriteLine();
            Console.WriteLine("Enter to exit . . .");
            Console.ReadLine();
            return;
        }
        
        Console.WriteLine("GGPK: " + contentPath);
        Console.WriteLine("Path in ggpk to extract: " + nodePath);
        Console.WriteLine("Path to save: " + outPath);

        if (contentPath.EndsWith(".bin")) 
        {
            Console.WriteLine("1:Reading _.index.bin file . . .");
            
            LibBundle3.Index? index = new Index(contentPath, false);
            index.ParsePaths();

            if (!index.TryFindNode(nodePath, out var node))
            {
                Console.WriteLine("No file at path: " + nodePath );
                return;
            }
            
            Console.WriteLine("File found at path: " + nodePath);
            Console.WriteLine("Extracting...");
            
            var extracted = Index.Extract(node, outPath);
            Console.WriteLine("Extracted: " + extracted);
            
        } else if (contentPath.EndsWith("ggpk")  && !nodePath.EndsWith(".bank") )
        {
            Console.WriteLine("2:Reading Content.ggpk file . . .")
                ;
            DirectoryNode? root = null;
            using var ggpk = new BundledGGPK(contentPath, false);
            var failed = ggpk.Index.ParsePaths();

            if (failed != 0)
            {
                var tmp = Console.ForegroundColor;
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine($"Warning: Failed to parse path of {failed} files in the index file");
                Console.ForegroundColor = tmp;
                root = ggpk.Index.BuildTree(true); 
            }
            
            Console.WriteLine("Searching files . . .");
            if (!ggpk.Index.TryFindNode(nodePath, out var node, root)) {
                Console.WriteLine("Not found in GGPK: " + nodePath);
                Console.WriteLine();
                Console.WriteLine("Enter to exit . . .");
                Console.ReadLine();
                return;
            }
                
            Console.WriteLine($"Done! Extracted {LibBundle3.Index.ExtractParallel(node, outPath, (fr, path) => {
                Console.WriteLine("Extracted: " + path);
                return false;
            })} files.");
        } else if (contentPath.EndsWith("ggpk") && nodePath.EndsWith(".bank"))
        {
            Console.WriteLine("3:Reading ggpk file . . .");

            using GGPK ggpk = new GGPK(contentPath);

            if ( !ggpk.Root.TryFindNode(nodePath, out var node) )
            {
                Console.WriteLine("No file at path: " + nodePath );
                return;
            }

            Console.WriteLine("File found at path: " + nodePath);
            Console.WriteLine("Extracting...");
            
            var extracted = GGPK.Extract(node, outPath);
            Console.WriteLine("Extracted: " + extracted);
        }
        
        Console.WriteLine("Press any key to exit..."); 
        Console.ReadLine();
    }
}
